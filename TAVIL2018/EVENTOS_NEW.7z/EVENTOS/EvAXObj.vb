﻿Imports System
Imports System.Text
Imports System.Linq
Imports System.Xml
Imports System.Reflection
Imports System.ComponentModel
Imports System.Collections
Imports System.Collections.Generic
Imports System.Windows
Imports System.Windows.Media.Imaging
Imports System.Windows.Forms
Imports System.IO
Imports Autodesk.AutoCAD.ApplicationServices
Imports Autodesk.AutoCAD.DatabaseServices
Imports Autodesk.AutoCAD.Runtime
Imports Autodesk.AutoCAD.EditorInput
Imports Autodesk.AutoCAD.Interop
Imports Autodesk.AutoCAD.Interop.Common
Imports Autodesk.AutoCAD.Geometry
Imports Autodesk.AutoCAD.Windows
Imports AcadApplication = Autodesk.AutoCAD.ApplicationServices.Application
Imports AcadDocument = Autodesk.AutoCAD.ApplicationServices.Document
Imports AcadWindows = Autodesk.AutoCAD.Windows
Imports uau = UtilesAlberto.Utiles
Imports a2 = AutoCAD2acad.A2acad
'
Namespace Eventos
    Partial Public Class AutoCADEventos
        Public Sub Subscribe_EvAXObj(ByRef ObjDB As Autodesk.AutoCAD.DatabaseServices.DBObject)
            If ObjDB Is Nothing Then Exit Sub
            If lTypesAXObj.Contains(ObjDB.GetType.Name) = False Then Exit Sub
            '
            AddHandler ObjDB.Cancelled, AddressOf EvObjDB_Cancelled
            AddHandler ObjDB.Copied, AddressOf EvObjDB_Copied
            AddHandler ObjDB.Erased, AddressOf EvObjDB_Erased
            AddHandler ObjDB.Goodbye, AddressOf EvObjDB_Goodbye
            AddHandler ObjDB.Modified, AddressOf EvObjDB_Modified
            AddHandler ObjDB.ModifiedXData, AddressOf EvObjDB_ModifiedXData
            AddHandler ObjDB.ModifyUndone, AddressOf EvObjDB_ModifyUndone
            AddHandler ObjDB.ObjectClosed, AddressOf EvObjDB_ObjectClosed
            AddHandler ObjDB.OpenedForModify, AddressOf EvObjDB_OpenedForModify
            AddHandler ObjDB.Reappended, AddressOf EvObjDB_Reappended
            AddHandler ObjDB.SubObjectModified, AddressOf EvObjDB_SubObjectModified
            AddHandler ObjDB.Unappended, AddressOf EvObjDB_Unappended
        End Sub
        Public Sub Unsubscribe_EvAXObj(ByRef ObjDB As DBObject)
            If ObjDB Is Nothing OrElse ObjDB.IsDisposed = True Then Exit Sub
            If lTypesAXObj.Contains(ObjDB.GetType.Name) = False Then Exit Sub
            'If ultimoId.Equals(ObjDB.ObjectId) Then ultimoId = Nothing
            'If lIds.Contains(ObjDB.Id) Then lIds.Remove(ObjDB.ObjectId)
            '
            RemoveHandler ObjDB.Cancelled, AddressOf EvObjDB_Cancelled
            RemoveHandler ObjDB.Copied, AddressOf EvObjDB_Copied
            RemoveHandler ObjDB.Erased, AddressOf EvObjDB_Erased
            RemoveHandler ObjDB.Goodbye, AddressOf EvObjDB_Goodbye
            RemoveHandler ObjDB.Modified, AddressOf EvObjDB_Modified
            RemoveHandler ObjDB.ModifiedXData, AddressOf EvObjDB_ModifiedXData
            RemoveHandler ObjDB.ModifyUndone, AddressOf EvObjDB_ModifyUndone
            RemoveHandler ObjDB.ObjectClosed, AddressOf EvObjDB_ObjectClosed
            RemoveHandler ObjDB.OpenedForModify, AddressOf EvObjDB_OpenedForModify
            RemoveHandler ObjDB.Reappended, AddressOf EvObjDB_Reappended
            RemoveHandler ObjDB.SubObjectModified, AddressOf EvObjDB_SubObjectModified
            RemoveHandler ObjDB.Unappended, AddressOf EvObjDB_Unappended
        End Sub
        Public Sub EvObjDB_Cancelled(sender As Object, e As EventArgs)

        End Sub

        Public Sub EvObjDB_Copied(sender As Object, e As ObjectEventArgs)

        End Sub

        Public Sub EvObjDB_Erased(sender As Object, e As ObjectErasedEventArgs)
            'If e.DBObject IsNot Nothing AndAlso e.Erased = False Then
            '    'Debug.Print(sender.Name)
            '    Unsubscribe_EvObjDB(sender)
            '    Unsubscribre_EvObjCOM(CType(sender, DBObject).AcadObject)
            'End If
        End Sub

        Public Sub EvObjDB_Goodbye(sender As Object, e As EventArgs)
            'Try
            '    Dim colPurge As New ObjectIdCollection
            '    Dim oDbO As DBObject = CType(sender, DBObject)
            '    If oDbO.IsErased Then
            '        colPurge.Add(oDbO.ObjectId)
            '        EvDocM.CurrentDocument.Database.Purge(colPurge)
            '    End If
            '    colPurge = Nothing
            '    oDbO = Nothing

            'Catch ex As System.Exception

            'End Try
        End Sub

        Public Sub EvObjDB_Modified(sender As Object, e As EventArgs)
            'Dim dbobj As DBObject = CType(sender, DBObject)
            'If TypeOf dbobj Is Autodesk.AutoCAD.DatabaseServices.BlockReference Then
            '    '        Using Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument.LockDocument
            '    '            'modTavil.AcadBlockReference_Modified(CType(queObj, Autodesk.AutoCAD.Interop.Common.AcadBlockReference))
            '    '            Try
            '    '                Dim queTipo As String = clsA.XLeeDato(CType(queObj, AcadObject), "tipo")
            '    '                'MsgBox(oBlr.EffectiveName & " Modificado")
            '    '                If colIds Is Nothing Then colIds = New List(Of Long)
            '    '                If colHan Is Nothing Then colHan = New List(Of String)
            '    '                If colIds.Contains(CType(queObj, AcadBlockReference).ObjectID) = False And queTipo = "cinta" Then
            '    '                    colIds.Add(CType(queObj, AcadBlockReference).ObjectID)
            '    '                    'colHan.Add(CType(queObj, AcadBlockReference).Handle)
            '    '                    ' Si vamos a modificar algo, poner app_procesointer = true (Para que no active eventos)
            '    '                    app_procesointerno = True
            '    '                    'clsA.SeleccionaPorHandle(Ev.EvApp.ActiveDocument, queObj, "_UPDATEFIELD")
            '    '                End If
            '    '            Catch ex As Exception
            '    '                Debug.Print(ex.ToString)
            '    '            End Try
            '    '        End Using
            'ElseIf TypeOf dbobj Is Circle Then
            '    EvDocM.CurrentDocument.Editor.WriteMessage(vbLf & "ActiveX Radio: " & CType(dbobj, Circle).Radius)
            'End If
        End Sub

        Public Sub EvObjDB_ModifiedXData(sender As Object, e As EventArgs)

        End Sub

        Public Sub EvObjDB_ModifyUndone(sender As Object, e As EventArgs)

        End Sub

        Public Sub EvObjDB_ObjectClosed(sender As Object, e As ObjectClosedEventArgs)
            If sender Is Nothing Then Exit Sub
            Debug.Print("Hola")
        End Sub

        Public Sub EvObjDB_OpenedForModify(sender As Object, e As EventArgs)

        End Sub

        Public Sub EvObjDB_Reappended(sender As Object, e As EventArgs)

        End Sub

        Public Sub EvObjDB_SubObjectModified(sender As Object, e As ObjectEventArgs)

        End Sub

        Public Sub EvObjDB_Unappended(sender As Object, e As EventArgs)
            'If sender IsNot Nothing Then
            '    Unsubscribe_EvObjDB(sender)
            '    Unsubscribre_EvObjCOM(CType(sender, DBObject).AcadObject)
            'End If
        End Sub
    End Class
End Namespace
'
'Cancelled          Se activa cuando la apertura del objeto es texto cancelado.
'Copied             Activado después de clonar el objeto.
'Erased             Se activa cuando el objeto se marca para borrar o se borra.
'Goodbye            Se activa cuando el objeto está a punto de eliminarse de la memoria porque su base de datos asociada se está destruyendo.
'Modified           Se activa cuando se modifica el objeto.
'ModifiedXData      Se activa cuando se modifica el XData adjunto al objeto.
'ModifyUndone       Se activa cuando se deshacen los cambios anteriores al objeto.
'ObjectClosed       Se activa cuando el objeto está cerrado.
'OpenedForModify    Se activa antes de que se modifique el objeto.
'Reappended         Se activa cuando el objeto se elimina de la base de datos después de una operación Deshacer Y luego se vuelve a agregar con una operación Rehacer..
'SubObjectModified  Se activa cuando se modifica un subobjeto del objeto.
'Unappended         Se activa cuando el objeto se elimina de la base de datos después de una operación Deshacer.

'Los siguientes son algunos de los eventos utilizados para responder a los cambios de objetos a nivel de base de datos
'ObjectAppended         Se activa cuando se agrega un objeto a una base de datos.
'ObjectErased           Se activa cuando un objeto se borra o borra de una base de datos.
'ObjectModified         Se activa cuando un objeto ha sido modificado.
'ObjectOpenedForModify  Se activa antes de que se modifique un objeto.
'ObjectReappended       Se activa cuando un objeto se elimina de una base de datos después de una operación Deshacer Y luego se vuelve a agregar con una operación Rehacer.
'ObjectUnappended       Se activa cuando un objeto se elimina de una base de datos después de una operación Deshacer.


