﻿Imports System
Imports System.Text
Imports System.Linq
Imports System.Xml
Imports System.Reflection
Imports System.ComponentModel
Imports System.Collections
Imports System.Collections.Generic
Imports System.Windows
Imports System.Windows.Media.Imaging
Imports System.Windows.Forms
Imports System.IO
Imports Autodesk.AutoCAD.ApplicationServices
Imports Autodesk.AutoCAD.DatabaseServices
Imports Autodesk.AutoCAD.Runtime
Imports Autodesk.AutoCAD.EditorInput
Imports Autodesk.AutoCAD.Interop
Imports Autodesk.AutoCAD.Interop.Common
Imports Autodesk.AutoCAD.Geometry
Imports Autodesk.AutoCAD.Windows
Imports AcadApplication = Autodesk.AutoCAD.ApplicationServices.Application
Imports AcadDocument = Autodesk.AutoCAD.ApplicationServices.Document
Imports AcadWindows = Autodesk.AutoCAD.Windows
Imports uau = UtilesAlberto.Utiles
Imports a2 = AutoCAD2acad.A2acad
'
Namespace Eventos
    Partial Public Class AutoCADEventos
        Public Sub Subscribre_EvCOMObj(ByRef pObject As AcadObject)
            'If pObject Is Nothing Then Exit Sub
            'If lTypesObjCOM.Contains(pObject.ObjectName) = False Then Exit Sub
            'If lHasCode.Contains(pObject.ObjectID.ToString) = True Then Exit Sub
            'lHasCode.Add(pObject.ObjectID.ToString)
            ''
            'If TypeOf pObject Is AcadBlockReference Then
            '    AddHandler pObject.Modified, AddressOf AcadBlockReference_Modified
            'ElseIf TypeOf pObject Is AcadCircle Then
            '    AddHandler pObject.Modified, AddressOf AcadCircle_Modified
            'End If
        End Sub
        Public Sub Unsubscribre_EvCOMObj(pObject As AcadObject)
            'If pObject Is Nothing Then Exit Sub
            'Try
            '    If lTypesObjCOM.Contains(pObject.ObjectName) = False Then Exit Sub
            '    If lHasCode.Contains(pObject.ObjectID.ToString) = False Then Exit Sub
            '    lHasCode.Remove(pObject.ObjectID.ToString)
            '    '
            '    If TypeOf pObject Is AcadBlockReference Then
            '        RemoveHandler pObject.Modified, AddressOf AcadBlockReference_Modified
            '    ElseIf TypeOf pObject Is AcadCircle Then
            '        RemoveHandler pObject.Modified, AddressOf AcadCircle_Modified
            '    End If
            'Catch ex As System.Exception

            'End Try
        End Sub
        Public Sub AcadCircle_Modified(pObject As AcadObject)
            'Try
            '    Dim oCi As AcadCircle = CType(pObject, AcadCircle)
            '    EvDocM.CurrentDocument.Editor.WriteMessage(vbLf & "COM Radio: " & oCi.Radius)
            'Catch ex As System.Exception

            'End Try
        End Sub

        Public Sub AcadBlockReference_Modified(pObject As AcadObject)
            'Try
            '    Dim oBl As AcadBlockReference = CType(pObject, AcadBlockReference)
            '    EvDocM.CurrentDocument.Editor.WriteMessage(vbLf & "COM Nombre: " & oBl.EffectiveNamef)
            'Catch ex As System.Exception

            'End Try
        End Sub
    End Class
End Namespace
