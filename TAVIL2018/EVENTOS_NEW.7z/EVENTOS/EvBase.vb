﻿Imports System
Imports System.Text
Imports System.Linq
Imports System.Xml
Imports System.Reflection
Imports System.ComponentModel
Imports System.Collections
Imports System.Collections.Generic
Imports System.Windows
Imports System.Windows.Media.Imaging
Imports System.Windows.Forms
Imports System.IO
Imports Autodesk.AutoCAD.ApplicationServices
Imports Autodesk.AutoCAD.DatabaseServices
Imports Autodesk.AutoCAD.Runtime
Imports Autodesk.AutoCAD.EditorInput
Imports Autodesk.AutoCAD.Interop
Imports Autodesk.AutoCAD.Interop.Common
Imports Autodesk.AutoCAD.Geometry
Imports Autodesk.AutoCAD.Windows
Imports AcadApplication = Autodesk.AutoCAD.ApplicationServices.Application
Imports AcadDocument = Autodesk.AutoCAD.ApplicationServices.Document
Imports AcadWindows = Autodesk.AutoCAD.Windows
Imports uau = UtilesAlberto.Utiles
Imports a2 = AutoCAD2acad.A2acad
'
Namespace Eventos
    Partial Public Class AutoCADEventos
        ' ***** OBJETOS AUTOCAD
        Public WithEvents EvAXWin As Autodesk.AutoCAD.Internal.Reactors.ApplicationEventManager
        Public WithEvents EvCOMApp As Autodesk.AutoCAD.Interop.AcadApplication = Nothing
        Public WithEvents EvAXApp As Autodesk.AutoCAD.ApplicationServices.Application
        Public EvAXDocM As Autodesk.AutoCAD.ApplicationServices.DocumentCollection
        'Public EvDoc As Autodesk.AutoCAD.Interop.AcadDocument = Nothing
        'Public EvDocS As Autodesk.AutoCAD.ApplicationServices.Document
        '
        'Public EvDb As Autodesk.AutoCAD.DatabaseServices.Database
        'Public EvObjDB As Autodesk.AutoCAD.DatabaseServices.DBObject
        'Public EvObjCOM As Autodesk.AutoCAD.Interop.Common.AcadObject
        '
        ' Los tipos de objetos que vamos a controlar con eventos
        Public lTypesAXObj As String() = {"BlockReference", "Circle"}
        Public lTypesObjCOM As String() = {"AcDbCircle", "AcDbBlockReference"}
        Public lHasCode As List(Of String)
        Public lIds As List(Of ObjectId)
        '
        ' Poner en variables generales
        '   Public Ev As Eventos.AutoCADEventos
        ' Poner en Initialice
        '   Ev = New Eventos.AutoCADEventos(CType(Autodesk.AutoCAD.ApplicationServices.Application.AcadApplication, Autodesk.AutoCAD.Interop.AcadApplication))

        Public Sub New()
            lHasCode = New List(Of String)
            lIds = New List(Of ObjectId)
            'If clsA Is Nothing Then clsA = New a2.A2acad(CType(Autodesk.AutoCAD.ApplicationServices.Application.AcadApplication, Autodesk.AutoCAD.Interop.AcadApplication).Application, cfg._appFullPath, regAPPCliente)
            EvAXWin = Autodesk.AutoCAD.Internal.Reactors.ApplicationEventManager.Instance
            EvCOMApp = CType(Autodesk.AutoCAD.ApplicationServices.Application.AcadApplication, Autodesk.AutoCAD.Interop.AcadApplication).Application
            EvAXDocM = AcadApplication.DocumentManager
            Subscribe_EvAppS()
            Subscribe_EvDocM()
            If (EvAXDocM.Count > 0) Then
                Subscribre_EvAXDoc(EvAXDocM.CurrentDocument)
            End If
        End Sub

        Public Sub AcadBlockReference_PonEventosModified()
            If clsA Is Nothing Then clsA = New a2.A2acad(EvCOMApp, cfg._appFullPath, regAPPCliente)
            'Dim AcadBlockReference As ArrayList = clsA.SeleccionaDameBloquesTODOS(regAPPA)
            'For Each oBl As AcadBlockReference In AcadBlockReference
            '    Dim queTipo As String = clsA.XLeeDato(oBl, "tipo")
            '    If queTipo = "cinta" Then
            '        AddHandler oBl.Modified, AddressOf modTavil.AcadBlockReference_Modified
            '    End If
            'Next
        End Sub
        '
        Public Function EvAXDoc() As Autodesk.AutoCAD.ApplicationServices.Document
            Return EvAXDocM.CurrentDocument
        End Function
        Public Function EvCOMDoc() As Autodesk.AutoCAD.Interop.AcadDocument
            Return EvAXDocM.CurrentDocument.GetAcadDocument
        End Function
        Public Function EvAXDb() As Autodesk.AutoCAD.DatabaseServices.Database
            Return EvAXDoc.Database
        End Function
        Public Function EvCOMDb() As Autodesk.AutoCAD.Interop.Common.AcadDatabase
            Return EvCOMDoc.Database
        End Function
        Public Function EvAXEditor() As Autodesk.AutoCAD.EditorInput.Editor
            Return EvAXDoc.Editor
        End Function
    End Class
End Namespace