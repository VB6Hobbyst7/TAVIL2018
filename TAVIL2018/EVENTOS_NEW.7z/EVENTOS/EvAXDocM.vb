﻿Imports System
Imports System.Text
Imports System.Linq
Imports System.Xml
Imports System.Reflection
Imports System.ComponentModel
Imports System.Collections
Imports System.Collections.Generic
Imports System.Windows
Imports System.Windows.Media.Imaging
Imports System.Windows.Forms
Imports System.IO
Imports Autodesk.AutoCAD.ApplicationServices
Imports Autodesk.AutoCAD.DatabaseServices
Imports Autodesk.AutoCAD.Runtime
Imports Autodesk.AutoCAD.EditorInput
Imports Autodesk.AutoCAD.Interop
Imports Autodesk.AutoCAD.Interop.Common
Imports Autodesk.AutoCAD.Geometry
Imports Autodesk.AutoCAD.Windows
Imports AcadApplication = Autodesk.AutoCAD.ApplicationServices.Application
Imports AcadDocument = Autodesk.AutoCAD.ApplicationServices.Document
Imports AcadWindows = Autodesk.AutoCAD.Windows
Imports a2 = AutoCAD2acad.A2acad
Namespace Eventos
    Partial Public Class AutoCADEventos
        Public Sub Subscribe_EvDocM()
            AddHandler AcadApplication.DocumentManager.DocumentActivated, AddressOf EvDocM_DocumentActivated
            AddHandler AcadApplication.DocumentManager.DocumentActivationChanged, AddressOf EvDocM_DocumentActivationChanged
            AddHandler AcadApplication.DocumentManager.DocumentBecameCurrent, AddressOf EvDocM_DocumentBecameCurrent
            AddHandler AcadApplication.DocumentManager.DocumentCreated, AddressOf EvDocM_DocumentCreated
            AddHandler AcadApplication.DocumentManager.DocumentCreateStarted, AddressOf EvDocM_DocumentCreateStarted
            AddHandler AcadApplication.DocumentManager.DocumentCreationCanceled, AddressOf EvDocM_DocumentCreationCanceled
            AddHandler AcadApplication.DocumentManager.DocumentDestroyed, AddressOf EvDocM_DocumentDestroyed
            AddHandler AcadApplication.DocumentManager.DocumentLockModeChanged, AddressOf EvDocM_DocumentLockModeChanged
            AddHandler AcadApplication.DocumentManager.DocumentLockModeChangeVetoed, AddressOf EvDocM_DocumentLockModeChangeVetoed
            AddHandler AcadApplication.DocumentManager.DocumentLockModeWillChange, AddressOf EvDocM_DocumentLockModeWillChange
            AddHandler AcadApplication.DocumentManager.DocumentToBeActivated, AddressOf EvDocM_DocumentToBeActivated
            AddHandler AcadApplication.DocumentManager.DocumentToBeDeactivated, AddressOf EvDocM_DocumentToBeDeactivated
            AddHandler AcadApplication.DocumentManager.DocumentToBeDestroyed, AddressOf EvDocM_DocumentToBeDestroyed
        End Sub
        Public Sub Unsubscribe_EvDocM()
            RemoveHandler AcadApplication.DocumentManager.DocumentActivated, AddressOf EvDocM_DocumentActivated
            RemoveHandler AcadApplication.DocumentManager.DocumentActivationChanged, AddressOf EvDocM_DocumentActivationChanged
            RemoveHandler AcadApplication.DocumentManager.DocumentBecameCurrent, AddressOf EvDocM_DocumentBecameCurrent
            RemoveHandler AcadApplication.DocumentManager.DocumentCreated, AddressOf EvDocM_DocumentCreated
            RemoveHandler AcadApplication.DocumentManager.DocumentCreateStarted, AddressOf EvDocM_DocumentCreateStarted
            RemoveHandler AcadApplication.DocumentManager.DocumentCreationCanceled, AddressOf EvDocM_DocumentCreationCanceled
            RemoveHandler AcadApplication.DocumentManager.DocumentDestroyed, AddressOf EvDocM_DocumentDestroyed
            RemoveHandler AcadApplication.DocumentManager.DocumentLockModeChanged, AddressOf EvDocM_DocumentLockModeChanged
            RemoveHandler AcadApplication.DocumentManager.DocumentLockModeChangeVetoed, AddressOf EvDocM_DocumentLockModeChangeVetoed
            RemoveHandler AcadApplication.DocumentManager.DocumentLockModeWillChange, AddressOf EvDocM_DocumentLockModeWillChange
            RemoveHandler AcadApplication.DocumentManager.DocumentToBeActivated, AddressOf EvDocM_DocumentToBeActivated
            RemoveHandler AcadApplication.DocumentManager.DocumentToBeDeactivated, AddressOf EvDocM_DocumentToBeDeactivated
            RemoveHandler AcadApplication.DocumentManager.DocumentToBeDestroyed, AddressOf EvDocM_DocumentToBeDestroyed
        End Sub
        Public Sub EvDocM_DocumentActivated(sender As Object, e As DocumentCollectionEventArgs)
        End Sub

        Public Sub EvDocM_DocumentActivationChanged(sender As Object, e As DocumentActivationChangedEventArgs)

        End Sub

        Public Sub EvDocM_DocumentBecameCurrent(sender As Object, e As DocumentCollectionEventArgs)

        End Sub

        Public Sub EvDocM_DocumentCreated(sender As Object, e As DocumentCollectionEventArgs)
            Subscribre_EvAXDoc(e.Document)
        End Sub

        Public Sub EvDocM_DocumentCreateStarted(sender As Object, e As DocumentCollectionEventArgs)

        End Sub

        Public Sub EvDocM_DocumentCreationCanceled(sender As Object, e As DocumentCollectionEventArgs)

        End Sub

        Public Sub EvDocM_DocumentDestroyed(sender As Object, e As DocumentDestroyedEventArgs)

        End Sub

        Public Sub EvDocM_DocumentLockModeChanged(sender As Object, e As DocumentLockModeChangedEventArgs)

        End Sub

        Public Sub EvDocM_DocumentLockModeChangeVetoed(sender As Object, e As DocumentLockModeChangeVetoedEventArgs)

        End Sub

        Public Sub EvDocM_DocumentLockModeWillChange(sender As Object, e As DocumentLockModeWillChangeEventArgs)

        End Sub

        Public Sub EvDocM_DocumentToBeActivated(sender As Object, e As DocumentCollectionEventArgs)

        End Sub

        Public Sub EvDocM_DocumentToBeDeactivated(sender As Object, e As DocumentCollectionEventArgs)

        End Sub

        Public Sub EvDocM_DocumentToBeDestroyed(sender As Object, e As DocumentCollectionEventArgs)
            Unsubscribre_EvAXDoc(e.Document)
        End Sub
    End Class
End Namespace
'
'DocumentActivated              Se activa cuando se activa una ventana de documento.
'DocumentActivationChanged      Se activa después de que la ventana del documento activo se desactiva o destruye.
'DocumentBecameCurrent          Se activa cuando una ventana de documento se configura como actual y es diferente de la ventana de documento activa anterior.
'DocumentCreated                Se activa después de crear una ventana de documento. Se produce después de que se crea un nuevo dibujo o se abre un dibujo existente.
'DocumentCreateStarted          Se activa justo antes de que se cree una ventana de documento. Ocurre antes de que se cree un nuevo dibujo o se abra un dibujo existente.
'DocumentCreationCanceled       Se activa cuando se cancela una solicitud para crear un nuevo dibujo o para abrir un dibujo existente.
'DocumentDestroyed              Se activa antes de que se destruya una ventana de documento y se elimine su objeto de base de datos asociado.
'DocumentLockModeChanged        Se activa después de que el modo de bloqueo de un documento ha cambiado.
'DocumentLockModeChangeVetoed   Se activa después de que se veta el cambio del modo de bloqueo.
'DocumentLockModeWillChange     Se activa antes de que se cambie el modo de bloqueo de un documento.
'DocumentToBeActivated          Se activa cuando un documento está a punto de activarse.
'DocumentToBeDeactivated        Se activa cuando un documento está a punto de desactivarse.
'DocumentToBeDestroyed          Se activa cuando un documento está a punto de ser destruido.
