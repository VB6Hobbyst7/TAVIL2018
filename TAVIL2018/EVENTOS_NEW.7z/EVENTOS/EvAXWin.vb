﻿Imports System
Imports System.Text
Imports System.Linq
Imports System.Xml
Imports System.Reflection
Imports System.ComponentModel
Imports System.Collections
Imports System.Collections.Generic
Imports System.Windows
Imports System.Windows.Media.Imaging
Imports System.Windows.Forms
Imports System.IO
Imports Autodesk.AutoCAD.ApplicationServices
Imports Autodesk.AutoCAD.DatabaseServices
Imports Autodesk.AutoCAD.Runtime
Imports Autodesk.AutoCAD.EditorInput
Imports Autodesk.AutoCAD.Interop
Imports Autodesk.AutoCAD.Interop.Common
Imports Autodesk.AutoCAD.Geometry
Imports Autodesk.AutoCAD.Windows
Imports AcadApplication = Autodesk.AutoCAD.ApplicationServices.Application
Imports AcadDocument = Autodesk.AutoCAD.ApplicationServices.Document
Imports AcadWindows = Autodesk.AutoCAD.Windows
Imports uau = UtilesAlberto.Utiles
Imports a2 = AutoCAD2acad.A2acad
'
Namespace Eventos
    Partial Public Class AutoCADEventos
        Public Sub EvWin_ApplicationDockLayoutChanged(sender As Object, e As EventArgs) Handles EvAXWin.ApplicationDockLayoutChanged

        End Sub

        Public Sub EvWin_ApplicationDocumentFrameChanged(sender As Object, e As EventArgs) Handles EvAXWin.ApplicationDocumentFrameChanged

        End Sub

        Public Sub EvWin_ApplicationMainWindowMoved(sender As Object, e As EventArgs) Handles EvAXWin.ApplicationMainWindowMoved

        End Sub

        Public Sub EvWin_ApplicationMainWindowSized(sender As Object, e As EventArgs) Handles EvAXWin.ApplicationMainWindowSized

        End Sub

        Public Sub EvWin_ApplicationMainWindowVisibleChanged(sender As Object, e As EventArgs) Handles EvAXWin.ApplicationMainWindowVisibleChanged

        End Sub
    End Class
End Namespace
