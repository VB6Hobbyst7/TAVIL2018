﻿Imports System
Imports System.Text
Imports System.Linq
Imports System.Xml
Imports System.Reflection
Imports System.ComponentModel
Imports System.Collections
Imports System.Collections.Generic
Imports System.Windows
Imports System.Windows.Media.Imaging
Imports System.Windows.Forms
Imports System.IO
Imports Autodesk.AutoCAD.ApplicationServices
Imports Autodesk.AutoCAD.DatabaseServices
Imports Autodesk.AutoCAD.Runtime
Imports Autodesk.AutoCAD.EditorInput
Imports Autodesk.AutoCAD.Interop
Imports Autodesk.AutoCAD.Interop.Common
Imports Autodesk.AutoCAD.Geometry
Imports Autodesk.AutoCAD.Windows
Imports AcadApplication = Autodesk.AutoCAD.ApplicationServices.Application
Imports AcadDocument = Autodesk.AutoCAD.ApplicationServices.Document
Imports AcadWindows = Autodesk.AutoCAD.Windows
Imports uau = UtilesAlberto.Utiles
Imports a2 = AutoCAD2acad.A2acad
'
Namespace Eventos
    Partial Public Class AutoCADEventos
        Public Sub EvApp_AppActivate() Handles EvCOMApp.AppActivate

        End Sub

        Public Sub EvApp_AppDeactivate() Handles EvCOMApp.AppDeactivate

        End Sub

        Public Sub EvApp_ARXLoaded(AppName As String) Handles EvCOMApp.ARXLoaded

        End Sub

        Public Sub EvApp_ARXUnloaded(AppName As String) Handles EvCOMApp.ARXUnloaded

        End Sub

        Public Sub EvApp_BeginCommand(CommandName As String) Handles EvCOMApp.BeginCommand

        End Sub

        Public Sub EvApp_BeginFileDrop(FileName As String, ByRef Cancel As Boolean) Handles EvCOMApp.BeginFileDrop

        End Sub

        Public Sub EvApp_BeginLisp(FirstLine As String) Handles EvCOMApp.BeginLisp

        End Sub

        Public Sub EvApp_BeginModal() Handles EvCOMApp.BeginModal

        End Sub

        Public Sub EvApp_BeginOpen(ByRef FileName As String) Handles EvCOMApp.BeginOpen

        End Sub

        Public Sub EvApp_BeginPlot(DrawingName As String) Handles EvCOMApp.BeginPlot

        End Sub

        Public Sub EvApp_BeginQuit(ByRef Cancel As Boolean) Handles EvCOMApp.BeginQuit

        End Sub

        Public Sub EvApp_BeginSave(FileName As String) Handles EvCOMApp.BeginSave

        End Sub

        Public Sub EvApp_EndCommand(CommandName As String) Handles EvCOMApp.EndCommand

        End Sub

        Public Sub EvApp_EndLisp() Handles EvCOMApp.EndLisp

        End Sub

        Public Sub EvApp_EndModal() Handles EvCOMApp.EndModal

        End Sub

        Public Sub EvApp_EndOpen(FileName As String) Handles EvCOMApp.EndOpen
            'Subscribre_EvDocS(EvDocM.CurrentDocument)
        End Sub

        Public Sub EvApp_EndPlot(DrawingName As String) Handles EvCOMApp.EndPlot

        End Sub

        Public Sub EvApp_EndSave(FileName As String) Handles EvCOMApp.EndSave

        End Sub

        Public Sub EvApp_LispCancelled() Handles EvCOMApp.LispCancelled

        End Sub

        Public Sub EvApp_NewDrawing() Handles EvCOMApp.NewDrawing

        End Sub

        Public Sub EvApp_SysVarChanged(SysvarName As String, newVal As Object) Handles EvCOMApp.SysVarChanged

        End Sub

        Public Sub EvApp_WindowChanged(WindowState As AcWindowState) Handles EvCOMApp.WindowChanged

        End Sub

        Public Sub EvApp_WindowMovedOrResized(HWNDFrame As Integer, bMoved As Boolean) Handles EvCOMApp.WindowMovedOrResized

        End Sub
    End Class
End Namespace
'
'AppActivate:           Se activa justo antes de que se active la ventana principal de la aplicación. 
'AppDeactivate:         Se activa justo antes de que se desactive la ventana principal de la aplicación. 
'ARXLoaded:             Se activa cuando se carga una aplicación ObjectARX. 
'ARXUnloaded:           Se activa cuando una aplicación ObjectARX se ha descargado. 
'BeginCommand:          Se activa inmediatamente después de que se emite un comando, pero antes de que se complete. 
'BeginFileDrop:         Se activa cuando se suelta un archivo en la ventana principal de la aplicación.
'BeginLISP:             Se activa inmediatamente después de que AutoCAD recibe una solicitud para evaluar una expresión LISP.
'BeginModal:            Se activa justo antes de que se muestre un cuadro de diálogo modal. 
'BeginOpen:             Se activa inmediatamente después de que AutoCAD recibe una solicitud para abrir un dibujo existente. 
'BeginPlot:             Se activa inmediatamente después de que AutoCAD recibe una solicitud para imprimir un dibujo.
'BeginQuit:             Se activa justo antes de que finalice una sesión de AutoCA. 
'BeginSave:             Se activa inmediatamente después de que AutoCAD recibe una solicitud para guardar el dibujo. 
'EndCommand:            Se activa inmediatamente después de que se completa un comandos.
'EndLISP:               Se activa al finalizar la evaluación de una expresión LISP.
'EndModal:              Se activa justo después de que se descarta un cuadro de diálogo modal.
'EndOpen:               Se activa inmediatamente después de que AutoCAD termina de abrir un dibujo existente.
'EndPlot:               Se activa después de que se haya enviado un documento a la impresora.
'EndSave:               Se activa cuando AutoCAD ha terminado de guardar el dibujog.
'LISPCancelled:         Se activa cuando se cancela la evaluación de una expresión LISP.
'NewDrawing:            Se activa justo antes de que se cree un nuevo dibujo.
'SysVarChanged:         Se activa cuando se cambia el valor de una variable del sistema.
'WindowChanged:         Se activa cuando hay un cambio en la ventana de la aplicación.
'WindowMovedOrResized:  Se activa justo después de que la ventana de la Aplicación se haya movido o cambiado de tamaño. 
