﻿Imports System
Imports System.Text
Imports System.Linq
Imports System.Xml
Imports System.Reflection
Imports System.ComponentModel
Imports System.Collections
Imports System.Collections.Generic
Imports System.Windows
Imports System.Windows.Media.Imaging
Imports System.Windows.Forms
Imports System.IO
Imports Autodesk.AutoCAD.ApplicationServices
Imports Autodesk.AutoCAD.DatabaseServices
Imports Autodesk.AutoCAD.Runtime
Imports Autodesk.AutoCAD.EditorInput
Imports Autodesk.AutoCAD.Interop
Imports Autodesk.AutoCAD.Interop.Common
Imports Autodesk.AutoCAD.Geometry
Imports Autodesk.AutoCAD.Windows
Imports AcadApplication = Autodesk.AutoCAD.ApplicationServices.Application
Imports AcadDocument = Autodesk.AutoCAD.ApplicationServices.Document
Imports AcadWindows = Autodesk.AutoCAD.Windows
Imports uau = UtilesAlberto.Utiles
Imports a2 = AutoCAD2acad.A2acad
'
Namespace Eventos
    Partial Public Class AutoCADEventos
        Public ultimoId As ObjectId = Nothing
        Public Sub Subscribe_EvAXDb(ByRef AXDb As Database) 'docDb As Autodesk.AutoCAD.DatabaseServices.Database)
            If AXDb Is Nothing Then Exit Sub
            AddHandler AXDb.AbortDxfOut, AddressOf EvDb_AbortDxfOut
            AddHandler AXDb.AbortSave, AddressOf EvDb_AbortSave
            AddHandler AXDb.BeginDeepClone, AddressOf EvDb_BeginDeepClone
            AddHandler AXDb.BeginDeepCloneTranslation, AddressOf EvDb_BeginDeepCloneTranslation
            AddHandler AXDb.BeginDxfIn, AddressOf EvDb_BeginDxfIn
            AddHandler AXDb.BeginDxfOut, AddressOf EvDb_BeginDxfOut
            AddHandler AXDb.BeginInsert, AddressOf EvDb_BeginInsert
            AddHandler AXDb.BeginSave, AddressOf EvDb_BeginSave
            AddHandler AXDb.BeginWblockBlock, AddressOf EvDb_BeginWblockBlock
            AddHandler AXDb.BeginWblockEntireDatabase, AddressOf EvDb_BeginWblockEntireDatabase
            AddHandler AXDb.BeginWblockObjects, AddressOf EvDb_BeginWblockObjects
            AddHandler AXDb.BeginWblockSelectedObjects, AddressOf EvDb_BeginWblockSelectedObjects
            AddHandler Autodesk.AutoCAD.DatabaseServices.Database.DatabaseConstructed, AddressOf EvDb_DatabaseConstructed
            AddHandler AXDb.DatabaseToBeDestroyed, AddressOf EvDb_DatabaseToBeDestroyed
            AddHandler AXDb.DeepCloneAborted, AddressOf EvDb_DeepCloneAborted
            AddHandler AXDb.DeepCloneEnded, AddressOf EvDb_DeepCloneEnded
            AddHandler AXDb.Disposed, AddressOf EvDb_Disposed
            AddHandler AXDb.DwgFileOpened, AddressOf EvDb_DwgFileOpened
            AddHandler AXDb.DxfInComplete, AddressOf EvDb_DxfInComplete
            AddHandler AXDb.DxfOutComplete, AddressOf EvDb_DxfOutComplete
            AddHandler AXDb.InitialDwgFileOpenComplete, AddressOf EvDb_InitialDwgFileOpenComplete
            AddHandler AXDb.InsertAborted, AddressOf EvDb_InsertAborted
            AddHandler AXDb.InsertEnded, AddressOf EvDb_InsertEnded
            AddHandler AXDb.InsertMappingAvailable, AddressOf EvDb_InsertMappingAvailable
            AddHandler AXDb.ObjectAppended, AddressOf EvDb_ObjectAppended
            AddHandler AXDb.ObjectErased, AddressOf EvDb_ObjectErased
            AddHandler AXDb.ObjectModified, AddressOf EvDb_ObjectModified
            AddHandler AXDb.ObjectOpenedForModify, AddressOf EvDb_ObjectOpenedForModify
            AddHandler AXDb.ObjectReappended, AddressOf EvDb_ObjectReappended
            AddHandler AXDb.ObjectUnappended, AddressOf EvDb_ObjectUnappended
            AddHandler AXDb.PartialOpenNotice, AddressOf EvDb_PartialOpenNotice
            AddHandler AXDb.ProxyResurrectionCompleted, AddressOf EvDb_ProxyResurrectionCompleted
            AddHandler AXDb.SaveComplete, AddressOf EvDb_SaveComplete
            AddHandler AXDb.SystemVariableChanged, AddressOf EvDb_SystemVariableChanged
            AddHandler AXDb.SystemVariableWillChange, AddressOf EvDb_SystemVariableWillChange
            AddHandler AXDb.WblockAborted, AddressOf EvDb_WblockAborted
            AddHandler AXDb.WblockEnded, AddressOf EvDb_WblockEnded
            AddHandler AXDb.WblockMappingAvailable, AddressOf EvDb_WblockMappingAvailable
            AddHandler AXDb.WblockNotice, AddressOf EvDb_WblockNotice
            AddHandler Autodesk.AutoCAD.DatabaseServices.Database.XrefAttachAborted, AddressOf EvDb_XrefAttachAborted
            AddHandler AXDb.XrefAttachEnded, AddressOf EvDb_XrefAttachEnded
            AddHandler AXDb.XrefBeginAttached, AddressOf EvDb_XrefBeginAttached
            AddHandler AXDb.XrefBeginOtherAttached, AddressOf EvDb_XrefBeginOtherAttached
            AddHandler AXDb.XrefBeginRestore, AddressOf EvDb_XrefBeginRestore
            AddHandler AXDb.XrefComandeered, AddressOf EvDb_XrefComandeered
            AddHandler AXDb.XrefPreXrefLockFile, AddressOf EvDb_XrefPreXrefLockFile
            AddHandler AXDb.XrefRedirected, AddressOf EvDb_XrefRedirected
            AddHandler AXDb.XrefRestoreAborted, AddressOf EvDb_XrefRestoreAborted
            AddHandler AXDb.XrefRestoreEnded, AddressOf EvDb_XrefRestoreEnded
            AddHandler AXDb.XrefSubCommandAborted, AddressOf EvDb_XrefSubCommandAborted
            AddHandler AXDb.XrefSubCommandEnd, AddressOf EvDb_XrefSubCommandEnd
            AddHandler AXDb.XrefSubCommandStart, AddressOf EvDb_XrefSubCommandStart
        End Sub
        '
        Public Sub Unsubscribe_EvAXDb(ByRef AXDb As Database)
            If AXDb Is Nothing Then Exit Sub
            If lHasCode.Contains(AXDb.Filename) = False Then Exit Sub
            lHasCode.Remove(AXDb.Filename)
            RemoveHandler AXDb.AbortDxfIn, AddressOf EvDb_AbortDxfIn
            RemoveHandler AXDb.AbortDxfOut, AddressOf EvDb_AbortDxfOut
            RemoveHandler AXDb.AbortSave, AddressOf EvDb_AbortSave
            RemoveHandler AXDb.BeginDeepClone, AddressOf EvDb_BeginDeepClone
            RemoveHandler AXDb.BeginDeepCloneTranslation, AddressOf EvDb_BeginDeepCloneTranslation
            RemoveHandler AXDb.BeginDxfIn, AddressOf EvDb_BeginDxfIn
            RemoveHandler AXDb.BeginDxfOut, AddressOf EvDb_BeginDxfOut
            RemoveHandler AXDb.BeginInsert, AddressOf EvDb_BeginInsert
            RemoveHandler AXDb.BeginSave, AddressOf EvDb_BeginSave
            RemoveHandler AXDb.BeginWblockBlock, AddressOf EvDb_BeginWblockBlock
            RemoveHandler AXDb.BeginWblockEntireDatabase, AddressOf EvDb_BeginWblockEntireDatabase
            RemoveHandler AXDb.BeginWblockObjects, AddressOf EvDb_BeginWblockObjects
            RemoveHandler AXDb.BeginWblockSelectedObjects, AddressOf EvDb_BeginWblockSelectedObjects
            RemoveHandler Autodesk.AutoCAD.DatabaseServices.Database.DatabaseConstructed, AddressOf EvDb_DatabaseConstructed
            RemoveHandler AXDb.DatabaseToBeDestroyed, AddressOf EvDb_DatabaseToBeDestroyed
            RemoveHandler AXDb.DeepCloneAborted, AddressOf EvDb_DeepCloneAborted
            RemoveHandler AXDb.DeepCloneEnded, AddressOf EvDb_DeepCloneEnded
            RemoveHandler AXDb.Disposed, AddressOf EvDb_Disposed
            RemoveHandler AXDb.DwgFileOpened, AddressOf EvDb_DwgFileOpened
            RemoveHandler AXDb.DxfInComplete, AddressOf EvDb_DxfInComplete
            RemoveHandler AXDb.DxfOutComplete, AddressOf EvDb_DxfOutComplete
            RemoveHandler AXDb.InitialDwgFileOpenComplete, AddressOf EvDb_InitialDwgFileOpenComplete
            RemoveHandler AXDb.InsertAborted, AddressOf EvDb_InsertAborted
            RemoveHandler AXDb.InsertEnded, AddressOf EvDb_InsertEnded
            RemoveHandler AXDb.InsertMappingAvailable, AddressOf EvDb_InsertMappingAvailable
            RemoveHandler AXDb.ObjectAppended, AddressOf EvDb_ObjectAppended
            RemoveHandler AXDb.ObjectErased, AddressOf EvDb_ObjectErased
            RemoveHandler AXDb.ObjectModified, AddressOf EvDb_ObjectModified
            RemoveHandler AXDb.ObjectOpenedForModify, AddressOf EvDb_ObjectOpenedForModify
            RemoveHandler AXDb.ObjectReappended, AddressOf EvDb_ObjectReappended
            RemoveHandler AXDb.ObjectUnappended, AddressOf EvDb_ObjectUnappended
            RemoveHandler AXDb.PartialOpenNotice, AddressOf EvDb_PartialOpenNotice
            RemoveHandler AXDb.ProxyResurrectionCompleted, AddressOf EvDb_ProxyResurrectionCompleted
            RemoveHandler AXDb.SaveComplete, AddressOf EvDb_SaveComplete
            RemoveHandler AXDb.SystemVariableChanged, AddressOf EvDb_SystemVariableChanged
            RemoveHandler AXDb.SystemVariableWillChange, AddressOf EvDb_SystemVariableWillChange
            RemoveHandler AXDb.WblockAborted, AddressOf EvDb_WblockAborted
            RemoveHandler AXDb.WblockEnded, AddressOf EvDb_WblockEnded
            RemoveHandler AXDb.WblockMappingAvailable, AddressOf EvDb_WblockMappingAvailable
            RemoveHandler AXDb.WblockNotice, AddressOf EvDb_WblockNotice
            RemoveHandler Autodesk.AutoCAD.DatabaseServices.Database.XrefAttachAborted, AddressOf EvDb_XrefAttachAborted
            RemoveHandler AXDb.XrefAttachEnded, AddressOf EvDb_XrefAttachEnded
            RemoveHandler AXDb.XrefBeginAttached, AddressOf EvDb_XrefBeginAttached
            RemoveHandler AXDb.XrefBeginOtherAttached, AddressOf EvDb_XrefBeginOtherAttached
            RemoveHandler AXDb.XrefBeginRestore, AddressOf EvDb_XrefBeginRestore
            RemoveHandler AXDb.XrefComandeered, AddressOf EvDb_XrefComandeered
            RemoveHandler AXDb.XrefPreXrefLockFile, AddressOf EvDb_XrefPreXrefLockFile
            RemoveHandler AXDb.XrefRedirected, AddressOf EvDb_XrefRedirected
            RemoveHandler AXDb.XrefRestoreAborted, AddressOf EvDb_XrefRestoreAborted
            RemoveHandler AXDb.XrefRestoreEnded, AddressOf EvDb_XrefRestoreEnded
            RemoveHandler AXDb.XrefSubCommandAborted, AddressOf EvDb_XrefSubCommandAborted
            RemoveHandler AXDb.XrefSubCommandEnd, AddressOf EvDb_XrefSubCommandEnd
            RemoveHandler AXDb.XrefSubCommandStart, AddressOf EvDb_XrefSubCommandStart
        End Sub
        Public Sub EvDb_AbortDxfIn(sender As Object, e As EventArgs)
            'AcadApplication.DocumentManager.GetDocument(TryCast(sender, Database)).Editor.WriteMessage("AbortDxfIn")
        End Sub

        Public Sub EvDb_AbortDxfOut(sender As Object, e As EventArgs)
            'AcadApplication.DocumentManager.GetDocument(TryCast(sender, Database)).Editor.WriteMessage("AbortDxfOut")
        End Sub

        Public Sub EvDb_AbortSave(sender As Object, e As EventArgs)
            'AcadApplication.DocumentManager.GetDocument(TryCast(sender, Database)).Editor.WriteMessage("AbortSave")
        End Sub

        Public Sub EvDb_BeginDeepClone(sender As Object, e As IdMappingEventArgs)
            'AcadApplication.DocumentManager.GetDocument(TryCast(sender, Database)).Editor.WriteMessage("BeginDeepClone")
        End Sub

        Public Sub EvDb_BeginDeepCloneTranslation(sender As Object, e As IdMappingEventArgs)
            'AcadApplication.DocumentManager.GetDocument(TryCast(sender, Database)).Editor.WriteMessage("BeginDeepCloneTranslation")
        End Sub

        Public Sub EvDb_BeginDxfIn(sender As Object, e As EventArgs)
            AcadApplication.DocumentManager.GetDocument(TryCast(sender, Database)).Editor.WriteMessage("BeginDxfIn")
        End Sub

        Public Sub EvDb_BeginDxfOut(sender As Object, e As EventArgs)
            ' AcadApplication.DocumentManager.GetDocument(TryCast(sender, Database)).Editor.WriteMessage("BeginDxfOut")
        End Sub

        Public Sub EvDb_BeginInsert(sender As Object, e As BeginInsertEventArgs)
            'AcadApplication.DocumentManager.GetDocument(TryCast(sender, Database)).Editor.WriteMessage("BeginInsert")
        End Sub

        Public Sub EvDb_BeginSave(sender As Object, e As DatabaseIOEventArgs)
            'AcadApplication.DocumentManager.GetDocument(TryCast(sender, Database)).Editor.WriteMessage("BeginSave")
        End Sub

        Public Sub EvDb_BeginWblockBlock(sender As Object, e As BeginWblockBlockEventArgs)
            'AcadApplication.DocumentManager.GetDocument(TryCast(sender, Database)).Editor.WriteMessage("BeginWblockBlock")
        End Sub

        Public Sub EvDb_BeginWblockEntireDatabase(sender As Object, e As BeginWblockEntireDatabaseEventArgs)
            'AcadApplication.DocumentManager.GetDocument(TryCast(sender, Database)).Editor.WriteMessage("BeginWblockEntireDatabase")
        End Sub

        Public Sub EvDb_BeginWblockObjects(sender As Object, e As BeginWblockObjectsEventArgs)
            'AcadApplication.DocumentManager.GetDocument(TryCast(sender, Database)).Editor.WriteMessage("BeginWblockObjects")
        End Sub

        Public Sub EvDb_BeginWblockSelectedObjects(sender As Object, e As BeginWblockSelectedObjectsEventArgs)
            'AcadApplication.DocumentManager.GetDocument(TryCast(sender, Database)).Editor.WriteMessage("BeginWblockSelectedObjects")
        End Sub

        Public Sub EvDb_DatabaseConstructed(sender As Object, e As EventArgs)
            'AcadApplication.DocumentManager.GetDocument(TryCast(sender, Database)).Editor.WriteMessage("DatabaseConstructed")
        End Sub

        Public Sub EvDb_DatabaseToBeDestroyed(sender As Object, e As EventArgs)
            'AcadApplication.DocumentManager.GetDocument(TryCast(sender, Database)).Editor.WriteMessage("DatabaseToBeDestroyed")
        End Sub

        Public Sub EvDb_DeepCloneAborted(sender As Object, e As EventArgs)
            'AcadApplication.DocumentManager.GetDocument(TryCast(sender, Database)).Editor.WriteMessage("DeepCloneAborted")
        End Sub

        Public Sub EvDb_DeepCloneEnded(sender As Object, e As EventArgs)
            'AcadApplication.DocumentManager.GetDocument(TryCast(sender, Database)).Editor.WriteMessage("DeepCloneEnded")
        End Sub

        Public Sub EvDb_Disposed(sender As Object, e As EventArgs)
            'AcadApplication.DocumentManager.GetDocument(TryCast(sender, Database)).Editor.WriteMessage("Disposed")
        End Sub

        Public Sub EvDb_DwgFileOpened(sender As Object, e As DatabaseIOEventArgs)
            'AcadApplication.DocumentManager.GetDocument(TryCast(sender, Database)).Editor.WriteMessage("DwgFileOpened")
        End Sub

        Public Sub EvDb_DxfInComplete(sender As Object, e As EventArgs)
            'AcadApplication.DocumentManager.GetDocument(TryCast(sender, Database)).Editor.WriteMessage("DxfInComplete")
        End Sub

        Public Sub EvDb_DxfOutComplete(sender As Object, e As EventArgs)
            'AcadApplication.DocumentManager.GetDocument(TryCast(sender, Database)).Editor.WriteMessage("DxfOutComplete")
        End Sub

        Public Sub EvDb_InitialDwgFileOpenComplete(sender As Object, e As EventArgs)
            'AcadApplication.DocumentManager.GetDocument(TryCast(sender, Database)).Editor.WriteMessage("InitialDwgFileOpenComplete")
        End Sub

        Public Sub EvDb_InsertAborted(sender As Object, e As EventArgs)
            'AcadApplication.DocumentManager.GetDocument(TryCast(sender, Database)).Editor.WriteMessage("InsertAborted")
        End Sub

        Public Sub EvDb_InsertEnded(sender As Object, e As EventArgs)
            'AcadApplication.DocumentManager.GetDocument(TryCast(sender, Database)).Editor.WriteMessage("InsertEnded")
        End Sub

        Public Sub EvDb_InsertMappingAvailable(sender As Object, e As IdMappingEventArgs)
            'AcadApplication.DocumentManager.GetDocument(TryCast(sender, Database)).Editor.WriteMessage("InsertMappingAvailable")
        End Sub

        Public Sub EvDb_ObjectAppended(sender As Object, e As ObjectEventArgs)
            'Dim oDb As Database = CType(sender, Database)
            'AcadApplication.DocumentManager.GetDocument(TryCast(sender, Database)).Editor.WriteMessage("ObjectAppended")
            If e.DBObject Is Nothing OrElse
                e.DBObject.IsErased = True OrElse
                e.DBObject.IsUndoing = True OrElse
                e.DBObject.IsWriteEnabled = True Then Exit Sub
            '
            Dim oObj As DBObject = e.DBObject
            If ultimoId.Equals(oObj.ObjectId) Then Exit Sub
            '
            Dim objName As String = oObj.GetType.Name
            Dim objId As ObjectId = oObj.ObjectId
            If lTypesAXObj.Contains(objName) AndAlso lIds.Contains(objId) = False Then
                lIds.Add(objId)
                ultimoId = e.DBObject.ObjectId
                Subscribe_EvAXObj(e.DBObject)
            End If
        End Sub

        Public Sub EvDb_ObjectErased(sender As Object, e As ObjectErasedEventArgs)
            'AcadApplication.DocumentManager.GetDocument(TryCast(sender, Database)).Editor.WriteMessage("ObjectErased")
            If e.Erased = False Then   ' e.DBObject.IsDisposed = False Then
                Try
                    If e.DBObject IsNot Nothing Then Unsubscribe_EvAXObj(e.DBObject)
                    If e.DBObject.AcadObject IsNot Nothing Then Unsubscribre_EvCOMObj(e.DBObject.AcadObject)
                Catch ex As System.Exception
                    '
                End Try
            End If
        End Sub

        Public Sub EvDb_ObjectModified(sender As Object, e As ObjectEventArgs)
            If e.DBObject Is Nothing OrElse
                e.DBObject.IsErased = True OrElse
                e.DBObject.IsUndoing = True OrElse
                e.DBObject.IsWriteEnabled = True Then Exit Sub
            '
            Dim oObj As DBObject = e.DBObject
            If ultimoId.Equals(oObj.ObjectId) Then Exit Sub
            '
            Dim objName As String = oObj.GetType.Name
            Dim objId As ObjectId = oObj.ObjectId
            If lTypesAXObj.Contains(objName) AndAlso lIds.Contains(objId) = False Then
                lIds.Add(objId)
                ultimoId = e.DBObject.ObjectId
                Subscribe_EvAXObj(e.DBObject)
            End If
        End Sub

        Public Sub EvDb_ObjectOpenedForModify(sender As Object, e As ObjectEventArgs)
            'AcadApplication.DocumentManager.GetDocument(TryCast(sender, Database)).Editor.WriteMessage("ObjectOpenedForModify")
        End Sub

        Public Sub EvDb_ObjectReappended(sender As Object, e As ObjectEventArgs)
            'AcadApplication.DocumentManager.GetDocument(TryCast(sender, Database)).Editor.WriteMessage("ObjectReappended")
        End Sub

        Public Sub EvDb_ObjectUnappended(sender As Object, e As ObjectEventArgs)
            'AcadApplication.DocumentManager.GetDocument(TryCast(sender, Database)).Editor.WriteMessage("ObjectUnappended")

        End Sub

        Public Sub EvDb_PartialOpenNotice(sender As Object, e As EventArgs)
            'AcadApplication.DocumentManager.GetDocument(TryCast(sender, Database)).Editor.WriteMessage("PartialOpenNotice")
        End Sub

        Public Sub EvDb_ProxyResurrectionCompleted(sender As Object, e As ProxyResurrectionCompletedEventArgs)
            'AcadApplication.DocumentManager.GetDocument(TryCast(sender, Database)).Editor.WriteMessage("ProxyResurrectionCompleted")
        End Sub

        Public Sub EvDb_SaveComplete(sender As Object, e As DatabaseIOEventArgs)
            'AcadApplication.DocumentManager.GetDocument(TryCast(sender, Database)).Editor.WriteMessage("SaveComplete")

        End Sub

        Public Sub EvDb_SystemVariableChanged(sender As Object, e As Autodesk.AutoCAD.DatabaseServices.SystemVariableChangedEventArgs)
            ' AcadApplication.DocumentManager.GetDocument(TryCast(sender, Database)).Editor.WriteMessage("SystemVariableChanged")
        End Sub

        Public Sub EvDb_SystemVariableWillChange(sender As Object, e As Autodesk.AutoCAD.DatabaseServices.SystemVariableChangingEventArgs)
            'AcadApplication.DocumentManager.GetDocument(TryCast(sender, Database)).Editor.WriteMessage("SystemVariableWillChange")
        End Sub

        Public Sub EvDb_WblockAborted(sender As Object, e As EventArgs)
            'AcadApplication.DocumentManager.GetDocument(TryCast(sender, Database)).Editor.WriteMessage("WblockAborted")
        End Sub

        Public Sub EvDb_WblockEnded(sender As Object, e As EventArgs)
            'AcadApplication.DocumentManager.GetDocument(TryCast(sender, Database)).Editor.WriteMessage("WblockEnded")
        End Sub

        Public Sub EvDb_WblockMappingAvailable(sender As Object, e As IdMappingEventArgs)
            'AcadApplication.DocumentManager.GetDocument(TryCast(sender, Database)).Editor.WriteMessage("WblockMappingAvailable")
        End Sub

        Public Sub EvDb_WblockNotice(sender As Object, e As WblockNoticeEventArgs)
            'AcadApplication.DocumentManager.GetDocument(TryCast(sender, Database)).Editor.WriteMessage("WblockNotice")
        End Sub

        Public Sub EvDb_XrefAttachAborted(sender As Object, e As EventArgs)
            ' AcadApplication.DocumentManager.GetDocument(TryCast(sender, Database)).Editor.WriteMessage("XrefAttachAborted")
        End Sub

        Public Sub EvDb_XrefAttachEnded(sender As Object, e As EventArgs)
            'AcadApplication.DocumentManager.GetDocument(TryCast(sender, Database)).Editor.WriteMessage("XrefAttachEnded")
        End Sub

        Public Sub EvDb_XrefBeginAttached(sender As Object, e As XrefBeginOperationEventArgs)
            'AcadApplication.DocumentManager.GetDocument(TryCast(sender, Database)).Editor.WriteMessage("XrefBeginAttached")
        End Sub

        Public Sub EvDb_XrefBeginOtherAttached(sender As Object, e As XrefBeginOperationEventArgs)
            'AcadApplication.DocumentManager.GetDocument(TryCast(sender, Database)).Editor.WriteMessage("XrefBeginOtherAttached")
        End Sub

        Public Sub EvDb_XrefBeginRestore(sender As Object, e As XrefBeginOperationEventArgs)
            'AcadApplication.DocumentManager.GetDocument(TryCast(sender, Database)).Editor.WriteMessage("XrefBeginRestore")
        End Sub

        Public Sub EvDb_XrefComandeered(sender As Object, e As XrefComandeeredEventArgs)
            'AcadApplication.DocumentManager.GetDocument(TryCast(sender, Database)).Editor.WriteMessage("XrefComandeered")
        End Sub

        Public Sub EvDb_XrefPreXrefLockFile(sender As Object, e As XrefPreXrefLockFileEventArgs)
            'AcadApplication.DocumentManager.GetDocument(TryCast(sender, Database)).Editor.WriteMessage("XrefPreXrefLockFile")
        End Sub

        Public Sub EvDb_XrefRedirected(sender As Object, e As XrefRedirectedEventArgs)
            'AcadApplication.DocumentManager.GetDocument(TryCast(sender, Database)).Editor.WriteMessage("XrefRedirected")
        End Sub

        Public Sub EvDb_XrefRestoreAborted(sender As Object, e As EventArgs)
            'AcadApplication.DocumentManager.GetDocument(TryCast(sender, Database)).Editor.WriteMessage("XrefRestoreAborted")
        End Sub

        Public Sub EvDb_XrefRestoreEnded(sender As Object, e As EventArgs)
            'AcadApplication.DocumentManager.GetDocument(TryCast(sender, Database)).Editor.WriteMessage("XrefRestoreEnded")
        End Sub

        Public Sub EvDb_XrefSubCommandAborted(sender As Object, e As XrefSubCommandEventArgs)
            'AcadApplication.DocumentManager.GetDocument(TryCast(sender, Database)).Editor.WriteMessage("XrefSubCommandAborted")
        End Sub

        Public Sub EvDb_XrefSubCommandEnd(sender As Object, e As XrefSubCommandEventArgs)
            'AcadApplication.DocumentManager.GetDocument(TryCast(sender, Database)).Editor.WriteMessage("XrefSubCommandEnd")
        End Sub

        Public Sub EvDb_XrefSubCommandStart(sender As Object, e As XrefVetoableSubCommandEventArgs)
            'AcadApplication.DocumentManager.GetDocument(TryCast(sender, Database)).Editor.WriteMessage("XrefSubCommandStart")
        End Sub
    End Class
End Namespace
'
'Los siguientes son algunos de los eventos utilizados para responder a los cambios de objetos a nivel de base de datos
'ObjectAppended         Se activa cuando se agrega un objeto a una base de datos.
'ObjectErased           Se activa cuando un objeto se borra o borra de una base de datos.
'ObjectModified         Se activa cuando un objeto ha sido modificado.
'ObjectOpenedForModify  Se activa antes de que se modifique un objeto.
'ObjectReappended       Se activa cuando un objeto se elimina de una base de datos después de una operación Deshacer Y luego se vuelve a agregar con una operación Rehacer.
'ObjectUnappended       Se activa cuando un objeto se elimina de una base de datos después de una operación Deshacer.