﻿Imports System
Imports System.Text
Imports System.Linq
Imports System.Xml
Imports System.Reflection
Imports System.ComponentModel
Imports System.Collections
Imports System.Collections.Generic
Imports System.Windows
Imports System.Windows.Media.Imaging
Imports System.Windows.Forms
Imports System.IO
Imports Autodesk.AutoCAD.ApplicationServices
Imports Autodesk.AutoCAD.DatabaseServices
Imports Autodesk.AutoCAD.Runtime
Imports Autodesk.AutoCAD.EditorInput
Imports Autodesk.AutoCAD.Interop
Imports Autodesk.AutoCAD.Interop.Common
Imports Autodesk.AutoCAD.Geometry
Imports Autodesk.AutoCAD.Windows
Imports AcadApplication = Autodesk.AutoCAD.ApplicationServices.Application
Imports AcadDocument = Autodesk.AutoCAD.ApplicationServices.Document
Imports AcadWindows = Autodesk.AutoCAD.Windows
Imports a2 = AutoCAD2acad.A2acad
'
Namespace Eventos
    Partial Public Class AutoCADEventos
        Public ultimoAXDoc As String = ""
        Public Sub Subscribre_EvAXDoc(ByRef AXDoc As Autodesk.AutoCAD.ApplicationServices.Document)
            If AXDoc Is Nothing Then Exit Sub
            If AXDoc.Database.Filename = ultimoAXDoc Then Exit Sub
            If AXDoc.Database.Filename.ToUpper.EndsWith("DWG") = False Then Exit Sub
            ultimoAXDoc = AXDoc.Database.Filename
            '
            AddHandler AXDoc.BeginDocumentClose, AddressOf EvAXDoc_BeginDocumentClose
            AddHandler AXDoc.BeginDwgOpen, AddressOf EvAXDoc_BeginDwgOpen
            AddHandler AXDoc.CloseAborted, AddressOf EvAXDoc_CloseAborted
            AddHandler AXDoc.CloseWillStart, AddressOf EvAXDoc_CloseWillStart
            AddHandler AXDoc.CommandCancelled, AddressOf EvAXDoc_CommandCancelled
            AddHandler AXDoc.CommandEnded, AddressOf EvAXDoc_CommandEnded
            AddHandler AXDoc.CommandFailed, AddressOf EvAXDoc_CommandFailed
            AddHandler AXDoc.CommandWillStart, AddressOf EvAXDoc_CommandWillStart
            AddHandler AXDoc.EndDwgOpen, AddressOf EvAXDoc_EndDwgOpen
            AddHandler AXDoc.ImpliedSelectionChanged, AddressOf EvAXDoc_ImpliedSelectionChanged
            AddHandler AXDoc.LayoutSwitched, AddressOf EvAXDoc_LayoutSwitched
            AddHandler AXDoc.LayoutSwitching, AddressOf EvAXDoc_LayoutSwitching
            AddHandler AXDoc.LispCancelled, AddressOf EvAXDoc_LispCancelled
            AddHandler AXDoc.LispEnded, AddressOf EvAXDoc_LispEnded
            AddHandler AXDoc.LispWillStart, AddressOf EvAXDoc_LispWillStart
            AddHandler AXDoc.UnknownCommand, AddressOf EvAXDoc_UnknownCommand
            AddHandler AXDoc.ViewChanged, AddressOf EvAXDoc_ViewChanged
            '
            Subscribe_EvAXDb(AXDoc.Database)
            Subscribe_EvCOMDoc(AXDoc.GetAcadDocument)
        End Sub

        Public Sub Unsubscribre_EvAXDoc(ByRef AXDoc As Autodesk.AutoCAD.ApplicationServices.Document)
            If AXDoc Is Nothing Then Exit Sub
            RemoveHandler AXDoc.BeginDocumentClose, AddressOf EvAXDoc_BeginDocumentClose
            RemoveHandler AXDoc.BeginDwgOpen, AddressOf EvAXDoc_BeginDwgOpen
            RemoveHandler AXDoc.CloseAborted, AddressOf EvAXDoc_CloseAborted
            RemoveHandler AXDoc.CloseWillStart, AddressOf EvAXDoc_CloseWillStart
            RemoveHandler AXDoc.CommandCancelled, AddressOf EvAXDoc_CommandCancelled
            RemoveHandler AXDoc.CommandEnded, AddressOf EvAXDoc_CommandEnded
            RemoveHandler AXDoc.CommandFailed, AddressOf EvAXDoc_CommandFailed
            RemoveHandler AXDoc.CommandWillStart, AddressOf EvAXDoc_CommandWillStart
            RemoveHandler AXDoc.EndDwgOpen, AddressOf EvAXDoc_EndDwgOpen
            RemoveHandler AXDoc.ImpliedSelectionChanged, AddressOf EvAXDoc_ImpliedSelectionChanged
            RemoveHandler AXDoc.LayoutSwitched, AddressOf EvAXDoc_LayoutSwitched
            RemoveHandler AXDoc.LayoutSwitching, AddressOf EvAXDoc_LayoutSwitching
            RemoveHandler AXDoc.LispCancelled, AddressOf EvAXDoc_LispCancelled
            RemoveHandler AXDoc.LispEnded, AddressOf EvAXDoc_LispEnded
            RemoveHandler AXDoc.LispWillStart, AddressOf EvAXDoc_LispWillStart
            RemoveHandler AXDoc.UnknownCommand, AddressOf EvAXDoc_UnknownCommand
            RemoveHandler AXDoc.ViewChanged, AddressOf EvAXDoc_ViewChanged
            '
            Unsubscribe_EvAXDb(AXDoc.Database)
            Unsubscribe_EvCOMDoc(AXDoc.GetAcadDocument)
        End Sub
        Public Sub EvAXDoc_BeginDocumentClose(sender As Object, e As DocumentBeginCloseEventArgs)

        End Sub

        Public Sub EvAXDoc_BeginDwgOpen(sender As Object, e As DrawingOpenEventArgs)

        End Sub

        Public Sub EvAXDoc_CloseAborted(sender As Object, e As EventArgs)

        End Sub

        Public Sub EvAXDoc_CloseWillStart(sender As Object, e As EventArgs)

        End Sub

        Public Sub EvAXDoc_CommandCancelled(sender As Object, e As CommandEventArgs)

        End Sub

        Public Sub EvAXDoc_CommandEnded(sender As Object, e As CommandEventArgs)
            ' Si no hay elementos añadidos o modificados, salir (lIds.Count = 0)
            If lIds.Count = 0 Then Exit Sub
            '
            For Each oId As ObjectId In lIds
                Dim oObj As DBObject = clsA.DBObject_Get(oId)
                If oObj.GetType.Name = "Circle" Then
                    EvAXEditor.WriteMessage(vbLf & "Radius: " & CType(oObj, Circle).Radius)
                ElseIf oObj.GetType.Name = "BlockReference" Then
                    EvAXEditor.WriteMessage(vbLf & "BlockName: " & CType(oObj, BlockReference).BlockName)
                End If
            Next
            lIds.Clear()
            '
            '*********************************************
        End Sub

        Public Sub EvAXDoc_CommandFailed(sender As Object, e As CommandEventArgs)

        End Sub

        Public Sub EvAXDoc_CommandWillStart(sender As Object, e As CommandEventArgs)
            lIds = New List(Of ObjectId)
        End Sub

        Public Sub EvAXDoc_EndDwgOpen(sender As Object, e As DrawingOpenEventArgs)

        End Sub

        Public Sub EvAXDoc_ImpliedSelectionChanged(sender As Object, e As EventArgs)

        End Sub

        Public Sub EvAXDoc_LayoutSwitched(sender As Object, e As LayoutSwitchedEventArgs)

        End Sub

        Public Sub EvAXDoc_LayoutSwitching(sender As Object, e As LayoutSwitchingEventArgs)

        End Sub

        Public Sub EvAXDoc_LispCancelled(sender As Object, e As EventArgs)

        End Sub

        Public Sub EvAXDoc_LispEnded(sender As Object, e As EventArgs)

        End Sub

        Public Sub EvAXDoc_LispWillStart(sender As Object, e As LispWillStartEventArgs)

        End Sub

        Public Sub EvAXDoc_UnknownCommand(sender As Object, e As UnknownCommandEventArgs)

        End Sub

        Public Sub EvAXDoc_ViewChanged(sender As Object, e As EventArgs)

        End Sub
    End Class
End Namespace
'
'BeginDocumentClose         Se activa justo después de que se recibe una solicitud Para cerrar un dibujo.
'BeginDwgOpen               Se activa cuando se va a abrir un dibujo.
'CloseAborted               Se activa cuando se cancela un intento de cerrar un dibujo.
'CloseWillStart             Se activa después del evento BeginDocumentClose y antes de cerrar el dibujo comienza.
'CommandCancelled           Se activa cuando un comando se cancela antes de que se complete.
'CommandEnded               Se activa inmediatamente después de que se completa un comando.
'CommandFailed              Se activa cuando un comando no se completa y no se cancela.
'CommandWillStart           Se activa inmediatamente después de que se emite un comando, pero antes de que se complete.
'EndDwgOpen                 Se activa cuando se abre un dibujo.
'ImpliedSelectionChanged    Se activa cuando cambia el conjunto de selección actual de pickfirst.
'LayoutSwitched             Se activa después de que un diseño se esté configurando como actual.
'LispCancelled              Se activa cuando se cancela la evaluación de una expresión LISP.
'LispEnded                  Se activa al finalizar la evaluación de una expresión LISP.
'LispWillStart              Se activa inmediatamente después de que AutoCAD recibe una solicitud Para evaluar una expresión LISP.
'UnknownCommand             Se dispara inmediatamente cuando se ingresa un comando desconocido en el símbolo del sistema.
'ViewChanged                Se activa después de que la vista de un dibujo ha cambiado.

